<?php
require('fpdf/fpdf.php');

// Fetch form data (ensure proper validation and sanitation in a real application)
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$court = $_POST['court'];
$date = $_POST['date'];
$timeSlots = $_POST['timeSlots'];
$venueSlots = $_POST['venueSlots'];
$price = $_POST['price'];

// Create new PDF instance
$pdf = new FPDF();
$pdf->AddPage();

// Set font for title
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'Jesselball Sports Centre Booking Invoice', 0, 1, 'C');

// Logo (replace with your logo file path relative to this PHP script)
$logoPath = 'C:/xampp/htdocs/FYP Project/Project book/assets/logoj.jpg';
$pdf->Image($logoPath, 10, 10, 30); // Insert logo at position (10, 10) with width 30

// Line break
$pdf->Ln(20);

// Set font for section headings
$pdf->SetFont('Arial', 'B', 12);

// Add customer details section
$pdf->Cell(0, 10, 'Customer Details', 0, 1);
$pdf->SetFont('Arial', '', 12);
$pdf->MultiCell(0, 10, 'Name: ' . $name, 0, 'L');
$pdf->MultiCell(0, 10, 'Email: ' . $email, 0, 'L');
$pdf->MultiCell(0, 10, 'Phone: ' . $phone, 0, 'L');

// Line break
$pdf->Ln(10);

// Add booking details section
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Booking Details', 0, 1);

// Set background color for headers
$pdf->SetFillColor(200, 220, 255); // Light blue background
$pdf->SetFont('Arial', 'B', 10);

// Define table headers
$pdf->Cell(30, 10, 'Court Type', 1, 0, 'C', true);
$pdf->Cell(30, 10, 'Date', 1, 0, 'C', true);
$pdf->Cell(40, 10, 'Time Slots', 1, 0, 'C', true);
$pdf->Cell(40, 10, 'Venue Slots', 1, 1, 'C', true);

// Set font for table content
$pdf->SetFont('Arial', '', 10);

// Add table rows with booking details
$pdf->Cell(30, 10, $court, 1, 0, 'C');
$pdf->Cell(30, 10, $date, 1, 0, 'C');
$pdf->Cell(40, 10, $timeSlots, 1, 0, 'C');
$pdf->Cell(40, 10, $venueSlots, 1, 1, 'C');

// Line break
$pdf->Ln(10);

// Add total price
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Total Price: RM ' . number_format($price, 2), 0, 1, 'R');

// Output the PDF
$pdf->Output('I', 'invoice.pdf');
?>
