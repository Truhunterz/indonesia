<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="adminstyle.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
</head>
<body>
    <div class="sidebar">
        <div class="logo"></div>
        <ul class="menu">
            <li>
                <a href="adminpage.php">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a href="bookdetails.php">
                    <i class="fas fa-clipboard-list"></i>
                    <span>Book details</span>
                </a>
            </li>
            <li class="active">
                <a href="events.php">
                    <i class="fas fa-calendar-alt"></i>
                    <span>Events</span>
                </a>
            </li>
            <li>
                <a href="setting.php">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </li>
            <li class="logout">
                <a href="login.php">
                    <i class="fas fa-door-open"></i> 
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <div class="main--content">
        <div class="header--wrapper">
            <div class="header--title">
                <span>Booking Events</span>
                <h2>Events & Tournament</h2> 
            </div>
            <div class="user--info">
                <img src="./assets/admin3.jpg" alt="Admin Image">
            </div>
        </div>
        <div class="card--container">
            <div class="main--title">
                Events
            </div>
            <div class="card--wrapper">
                <div class="card--container2">
                    <h3>Event Title</h3>
                    <p>Date: DD/MM/YYYY</p>
                    <p>Time: HH:MM AM/PM</p>
                    <p>Description: about event</p>
                    <br>
                    <h3>Event Form</h3>
                    <form action="submitevent.php" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="title">Event Title:</label>
                            <input type="text" id="title" name="title" required>
                        </div>
                        <div class="form-group">
                            <label for="date">Date:</label>
                            <input type="date" id="date" name="date" required>
                        </div>
                        <div class="form-group">
                            <label for="time">Time:</label>
                            <input type="time" id="time" name="time" required>
                        </div>
                        <div class="form-group">
                            <label for="description">Description:</label>
                            <textarea id="description" name="description" rows="4" required></textarea>
                        </div>
                        <button type="submit" class="submit-button">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
