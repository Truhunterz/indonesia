<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jesselball";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM events";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo '<section class="events" id="events">';
    echo '<h2>Upcoming Events</h2>';
    echo '<div class="event-list">';

    while($row = $result->fetch_assoc()) {
        echo '<div class="event">';
        echo '<h3>' . $row["title"] . '</h3>';
        echo '<p>Date: ' . $row["date"] . '</p>';
        echo '<p>Time: ' . $row["time"] . '</p>';
        echo '<p>Description: ' . $row["description"] . '</p>';
        if (!empty($row["image"])) {
            echo '<img src="data:image/jpeg;base64,' . base64_encode($row["image"]) . '" alt="' . $row["title"] . '">';
        }
        echo '</div>';
    }

    echo '</div>';
    echo '</section>';
} else {
    echo "No events found.";
}

$conn->close();
?>
