<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jesselball";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the database
$sql = "SELECT id, name, email, phone, court, date, time_slots, venue_slots, price, receipt_file, created_at FROM bookings";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="adminstyle.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
</head>

<style>
    .table--controls {
        display: flex;
        justify-content: flex-end;
        margin-bottom: 10px;
    }

    .table--controls button {
        margin-left: 10px;
    }
</style>

<body>
<div class="sidebar">
    <div class="logo"></div>
    <ul class="menu">
        <li class="active">
            <a href="adminpage.php">
                <i class="fas fa-home"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="bookdetails.php">
                <i class="fas fa-clipboard-list"></i>
                <span>Book details</span>
            </a>
        </li>
        <li>
            <a href="Events.php">
                <i class="fas fa-calendar-alt"></i>
                <span>Event</span>
            </a>
        </li>
        <li>
            <a href="setting.php">
                <i class="fas fa-cog"></i>
                <span>Settings</span>
            </a>
        </li>
        <li class="logout">
            <a href="login.php">
                <i class="fas fa-door-open"></i> 
                <span>Logout</span>
            </a>
        </li>
    </ul>
</div>

<div class="main--content">
    <div class="header--wrapper">
        <div class="header--title">
            <span>User Booking</span>
            <h2>Booking Overview</h2> 
        </div>
        <div class="user--info">
            <div class="search--box">
                <i class="fas fa-search"></i>
                <input type="text" id="searchInput" placeholder="Search" onkeyup="searchTable()">
            </div>
            <img src="./assets/admin3.jpg" alt="Admin Image">
        </div>
    </div>
    <div class="booking--details">
        <h2 class="main--title">Booking Details</h2>
        <div class="table--controls">
            <button onclick="sortTable(4)">Sort by Court</button>
            <button onclick="sortTable(5)">Sort by Date</button>
        </div>
        <div class="table--container">
            <table id="bookingTable">
                <thead>
                    <tr>
                        <th>id</th>
                        <th>name</th>
                        <th>email</th>
                        <th>phone</th>
                        <th>court</th>
                        <th>date</th>
                        <th>time slots</th>
                        <th>venue slots</th>
                        <th>price</th>
                        <th>current book time</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row["id"] . "</td>";
                            echo "<td>" . $row["name"] . "</td>";
                            echo "<td>" . $row["email"] . "</td>";
                            echo "<td>" . $row["phone"] . "</td>";
                            echo "<td>" . $row["court"] . "</td>";
                            echo "<td>" . $row["date"] . "</td>";
                            echo "<td>" . $row["time_slots"] . "</td>";
                            echo "<td>" . $row["venue_slots"] . "</td>";
                            echo "<td>" . $row["price"] . "</td>";
                            echo "<td>" . $row["created_at"] . "</td>";
                            echo "<td>
                                    <button class='action-button' onclick='deleteBooking(" . $row["id"] . ")'>Delete</button>
                                    <a href='download.php?id=" . $row["id"] . "'<button class='action-button'>Download</button</a>
                                </td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='11'>No bookings found</td></tr>";
                    }
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>
        <div class="manage--buttons">
            <button onclick="addBooking()">Add Booking</button>
        </div>
    </div>
</div>

<script>
    function searchTable() {
        var input, filter, table, tr, td, i, j, txtValue;
        input = document.getElementById("searchInput");
        filter = input.value.toLowerCase();
        table = document.getElementById("bookingTable");
        tr = table.getElementsByTagName("tr");

        for (i = 1; i < tr.length; i++) {
            tr[i].style.display = "none";
            td = tr[i].getElementsByTagName("td");
            for (j = 0; j < td.length; j++) {
                if (td[j]) {
                    txtValue = td[j].textContent || td[j].innerText;
                    if (txtValue.toLowerCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                        break;
                    }
                }
            }
        }
    }

    function deleteBooking(id) {
        if (confirm('Are you sure you want to delete this booking?')) {
            window.location.href = 'delete.php?id=' + id;
        }
    }

    function sortTable(columnIndex) {
        var table, rows, switching, i, x, y, shouldSwitch, direction, switchCount = 0;
        table = document.getElementById("bookingTable");
        switching = true;
        direction = "asc"; // Set the sorting direction to ascending

        while (switching) {
            switching = false;
            rows = table.rows;

            for (i = 1; i < (rows.length - 1); i++) {
                shouldSwitch = false;
                x = rows[i].getElementsByTagName("TD")[columnIndex];
                y = rows[i + 1].getElementsByTagName("TD")[columnIndex];

                if (direction == "asc") {
                    if (columnIndex == 5) { // If sorting by date
                        if (new Date(x.innerHTML) > new Date(y.innerHTML)) {
                            shouldSwitch = true;
                            break;
                        }
                    } else {
                        if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                            shouldSwitch = true;
                            break;
                        }
                    }
                } else if (direction == "desc") {
                    if (columnIndex == 5) { // If sorting by date
                        if (new Date(x.innerHTML) < new Date(y.innerHTML)) {
                            shouldSwitch = true;
                            break;
                        }
                    } else {
                        if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                            shouldSwitch = true;
                            break;
                        }
                    }
                }
            }

            if (shouldSwitch) {
                rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                switching = true;
                switchCount++;
            } else {
                if (switchCount == 0 && direction == "asc") {
                    direction = "desc";
                    switching = true;
                }
            }
        }
    }
</script>
</body>
</html>
